# Python MCP Template

Skeleton project for a Python-based MCP server.

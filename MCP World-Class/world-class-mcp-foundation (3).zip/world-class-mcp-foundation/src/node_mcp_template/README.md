# Node MCP Template

Skeleton project for a Node.js MCP server.

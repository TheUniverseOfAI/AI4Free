
# 🌐 World-Class MCP Foundation

Skeleton repo for learning and designing **MCP (Model Context Protocol)** systems,
mirroring your RAG foundation structure.

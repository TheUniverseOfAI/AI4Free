# MCP Glossary

Add definitions for MCP, tools, resources, prompts, sessions, etc.

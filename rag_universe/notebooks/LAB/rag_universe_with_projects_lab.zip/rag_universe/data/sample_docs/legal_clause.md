# Sample Contract Excerpt

SECTION 4. TERMINATION

Either party may terminate this Agreement upon thirty (30) days' written notice if the other party materially breaches any provision of this Agreement and fails to cure such breach within the notice period.

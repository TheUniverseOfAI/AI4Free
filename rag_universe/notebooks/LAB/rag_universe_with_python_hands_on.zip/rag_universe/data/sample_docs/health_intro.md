# What Is Hypertension?

Hypertension, or high blood pressure, is a chronic medical condition in which the blood pressure in the arteries is persistently elevated.

It is often called a "silent killer" because many people have no symptoms but are still at risk of serious health problems.
